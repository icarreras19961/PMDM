package com.example.flis;

public class MyThread extends Thread{
    @Override
    public void run(){

    }
}