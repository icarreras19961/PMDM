package com.example.asteriods;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button sobre_switch;
    Button preferencias_switch;
    Button score_switch;
    public static ScoreStorage scoreStorage = new ScoreStorageList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        sobre_switch = findViewById(R.id.button9);
        sobre_switch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sobreSwitch(null);
            }
        });

        preferencias_switch = findViewById(R.id.button8);
        preferencias_switch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                preferencesSwitch(null);
            }
        });

        score_switch = findViewById(R.id.button10);
        score_switch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showScores(null);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


    }

    //El boton de sobre
    public void sobreSwitch(View view) {
        Intent i = new Intent(this, SobreActivity.class);
        startActivity(i);
    }

    //El switch a la pagina preferencias
    public void preferencesSwitch(View view) {
        Intent i = new Intent(this, PreferencesActivity.class);
        startActivity(i);
    }
    //El switch a puntuacion
    public void showScores(View view) {
        Intent i = new Intent(this, Scores.class);
        startActivity(i);
    }
    //El menu "actionbar"
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.preferences) {
            //arrancar activitat preferències
            preferencesSwitch(null);
        }
        if (id == R.id.about) {
            //arrancar activitat sobre...
            sobreSwitch(null);
        }
        return super.onOptionsItemSelected(item);
    }
}